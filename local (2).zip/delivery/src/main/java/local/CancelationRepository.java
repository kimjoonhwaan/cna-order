package local;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface CancelationRepository extends PagingAndSortingRepository<Cancelation, Long>{


}